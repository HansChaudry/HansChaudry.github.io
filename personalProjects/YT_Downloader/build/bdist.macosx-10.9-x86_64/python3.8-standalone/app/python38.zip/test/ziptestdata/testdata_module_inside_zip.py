# Test data file to be stored within a zip file.
FAVORITE_NUMBER = 5
